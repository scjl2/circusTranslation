package scjlevel2examples.flatbuffer;

public abstract class testAbstractClass implements testInterface
{

}
