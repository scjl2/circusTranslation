package scjlevel2examples.flatbuffer;

public interface testInterface
{

}
