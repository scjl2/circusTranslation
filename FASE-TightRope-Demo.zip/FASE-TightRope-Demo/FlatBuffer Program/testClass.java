package scjlevel2examples.flatbuffer;

public class testClass extends testAbstractClass
{

}
