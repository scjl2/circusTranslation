-------------
SCJ PapaBench 
-------------


Introduction
------------

Implementation
--------------

License
-------


Further reading
----------------
[1] Paparazzi WIKI - http://paparazzi.enac.fr/wiki/Main_Page
[2] PapaBench - http://www.irit.fr/recherches/ARCHI/MARCH/rubrique.php3?id_rubrique=97




