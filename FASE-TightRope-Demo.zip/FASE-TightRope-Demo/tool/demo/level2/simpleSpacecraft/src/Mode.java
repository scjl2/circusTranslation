/** Spacecraft - Mode Change Example
 * 
 * 	Marker interface identifying a Mode
 * 
 *   @author Matt Luckcuck <ml881@york.ac.uk>
 */
package scjlevel2examples.spacecraft;

public interface Mode
{

}
