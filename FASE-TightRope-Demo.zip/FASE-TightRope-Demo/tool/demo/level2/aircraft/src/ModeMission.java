package scjlevel2examples.aircraft;

import javax.safetycritical.Mission;

public abstract class ModeMission extends Mission
{

}
