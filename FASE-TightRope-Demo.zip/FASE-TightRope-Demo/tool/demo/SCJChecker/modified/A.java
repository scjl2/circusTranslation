class A {

    void bar() {}

}
