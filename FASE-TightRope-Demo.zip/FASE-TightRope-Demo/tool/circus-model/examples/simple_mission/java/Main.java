import javax.safetycritical.SafeletExecuter;

public class Main {
   public static void main(String[] args) {
      SafeletExecuter.run(new MainSafelet());
   }
}
