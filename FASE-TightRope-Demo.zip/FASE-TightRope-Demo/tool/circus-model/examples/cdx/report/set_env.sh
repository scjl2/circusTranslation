#!/bin/sh

# Note that this script must be executed via "source set_env.sh".

CDX_REPORT=$(readlink -f $(dirname $0))

CZT_PATH=$CDX_REPORT/models:$CZT_PATH
CZT_PATH=$CDX_REPORT/classes:$CZT_PATH

export CZT_PATH
