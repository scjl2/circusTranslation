package accs;

import javax.safetycritical.Safelet;
import javax.safetycritical.MissionSequencer;

import javax.safetycritical.annotate.*;

public class ACCSafelet implements Safelet {
  public ACCSafelet() { }

  public void setup() { }

  public void teardown() { }

  public MissionSequencer getSequencer() {
    return new ACCMissionSequencer();
  }
}
