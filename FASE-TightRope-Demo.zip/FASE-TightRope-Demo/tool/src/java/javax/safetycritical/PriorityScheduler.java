package javax.safetycritical;

import javax.safetycritical.annotate.*;

@SCJAllowed(Level.LEVEL_1)
public class PriorityScheduler extends javax.realtime.PriorityScheduler {
  @SCJAllowed(Level.LEVEL_1)
  public int getMaxHardwarePriority() {
    return 0;
  }

  @SCJAllowed(Level.LEVEL_1)
  public int getMinHardwarePriority() {
    return 0;
  }

  @SCJAllowed(Level.LEVEL_1)
  public static PriorityScheduler instance() {
    return null;
  }
}
