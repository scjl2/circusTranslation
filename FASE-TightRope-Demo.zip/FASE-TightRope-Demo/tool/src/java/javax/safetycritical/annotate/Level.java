package javax.safetycritical.annotate;

public enum Level {
  LEVEL_0,
  LEVEL_1,
  LEVEL_2,
  INFRASTRUCTURE,
  HIDDEN,
  SUPPORT
}
