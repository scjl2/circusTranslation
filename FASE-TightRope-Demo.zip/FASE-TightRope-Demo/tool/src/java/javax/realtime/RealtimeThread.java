package javax.realtime;

public class RealtimeThread extends Thread {

    public RealtimeThread() {
    }

    public static void sleep(HighResolutionTime time) throws InterruptedException {
    } 
   
}
