package javax.realtime;

import javax.safetycritical.annotate.*;

@SCJAllowed
public class Clock {

    public static Clock getRealtimeClock() {
        return null;
    }

    public AbsoluteTime getTime() {
        return null;
    }

}
