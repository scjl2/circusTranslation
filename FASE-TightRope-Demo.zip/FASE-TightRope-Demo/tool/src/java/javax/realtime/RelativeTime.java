package javax.realtime;

import javax.safetycritical.annotate.*;

/* TODO: The stub for this class is not fully specified yet. */

@SCJAllowed
public class RelativeTime extends HighResolutionTime {
  @SCJAllowed
  public RelativeTime(long ms, int ns) {
  }

  public long getMilliseconds() {
    return 0;
  }

}
