package javax.realtime;

import javax.safetycritical.annotate.*;

@SCJAllowed
public class AbstractAsyncEventHandler implements Schedulable {
  @Override
  public void run() {
  }
}
