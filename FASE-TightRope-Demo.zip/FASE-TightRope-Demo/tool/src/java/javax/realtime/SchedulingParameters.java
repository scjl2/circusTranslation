package javax.realtime;

import javax.safetycritical.annotate.*;

@SCJAllowed
public abstract class SchedulingParameters {
}
