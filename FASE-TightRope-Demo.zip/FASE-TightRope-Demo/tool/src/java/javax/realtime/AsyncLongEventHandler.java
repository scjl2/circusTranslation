package javax.realtime;

import javax.safetycritical.annotate.*;

@SCJAllowed
public abstract class AsyncLongEventHandler extends AbstractAsyncEventHandler {
  @Ignore
  @SCJAllowed(Level.SUPPORT)
  public abstract void handleAsyncLongEvent(long value);
}
