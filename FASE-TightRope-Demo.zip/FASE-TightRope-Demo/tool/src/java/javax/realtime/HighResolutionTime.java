package javax.realtime;

import javax.safetycritical.annotate.*;

/* TODO: The stub for this class is not fully specified yet. */

@SCJAllowed
public abstract class HighResolutionTime {
}
