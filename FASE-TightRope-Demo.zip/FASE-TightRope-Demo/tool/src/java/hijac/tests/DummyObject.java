package hijac.tests;

class DummyObject extends Object {
   public DummyObject() { }
}
