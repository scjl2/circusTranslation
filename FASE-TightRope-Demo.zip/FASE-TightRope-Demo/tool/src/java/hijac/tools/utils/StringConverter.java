package hijac.tools.utils;

/**
 * @author Frank Zeyda
 * @version $Revision: 198 $
 */
public interface StringConverter <T> {
   public String toString(T o);
}
