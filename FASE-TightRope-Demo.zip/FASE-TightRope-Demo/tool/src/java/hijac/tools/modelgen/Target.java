package hijac.tools.modelgen;

/**
 * Marker interface that must be implemented by all classes acting as
 * translation targets.
 *
 * @author Frank Zeyda
 * @version $Revision$
 */
public interface Target {
}
