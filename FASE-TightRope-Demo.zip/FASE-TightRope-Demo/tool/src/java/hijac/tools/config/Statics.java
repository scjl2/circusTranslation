package hijac.tools.config;

/**
 * @author Frank Zeyda
 * @version $Revision: 198 $
 */
public class Statics {
   public static void kickstart() {
      Tasks.kickstart();
   }
}
