package scjlevel2examples.modechange;
//This marker interface shows that a particular class is a Mode
public interface Mode 
{
	
}
